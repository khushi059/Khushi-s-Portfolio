#pratical ques1
num= int(input("Enter the number: "))
if num%2==0:
    print("yes")
else:
    print("no")
    
#pratical ques2
x=7
y=9
highest=max(x,y)
print(highest)